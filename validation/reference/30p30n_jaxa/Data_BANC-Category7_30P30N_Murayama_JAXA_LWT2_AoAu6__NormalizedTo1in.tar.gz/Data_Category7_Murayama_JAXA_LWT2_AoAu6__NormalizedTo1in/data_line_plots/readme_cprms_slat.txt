TITLE     = "RMS Cp Fluctuations"
VARIABLES = "x/c" "y(mm)"  "Cp' rms" "comment"
CASE_IDZONE T=""
 DT=(DOUBLE DOUBLE)
-0.034791666	-50.85120916	0.01037002	outside of cove of slat
0.0058053	-3.226509849	0.209121322	lower surface of slat
0.006481706	-1.01167767	0.012867451	upper surface of slat